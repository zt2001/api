 
function close(){
  $('#loading').hide();
    $('#player').remove();
    $('#error').show();
    $("#error").html('<h1>出于安全考虑：如果你是开发者请更新到最新版本，如果你是用户请尽快联系管理员更新！</h1>');
}
close();